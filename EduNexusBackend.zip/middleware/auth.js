module.exports = (req, res, next) => {
  const adminIds = process.env.TELEGRAM_ADMIN_IDS.split(",");
  const telegramId = req.headers["x-telegram-id"];
  
  if (!telegramId || !adminIds.includes(telegramId)) {
    return res.status(403).json({ message: "Forbidden: Admin access only" });
  }
  
  next();
};